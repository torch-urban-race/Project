package com.company;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketServer {

    //Port number
    int PortNumber =45454;
    ServerSocket serverSocket = null;

    /**
     * This method will run our server
     *
     */

    public void runServer(){
        try {

            serverSocket = new ServerSocket(PortNumber);
           // serverSocket.setSoTimeout(1000);

        } catch (IOException e) {
            e.printStackTrace();
        }

        // The Server will keep running  and accept multiple clint's
        while (true){
            try {
                Socket clintSocket = serverSocket.accept();
                //new Thread().start();
                new Thread(new TorchAppRunnable(clintSocket)).start();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

}


