package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TorchAppRunnable  implements Runnable{

    protected Socket clientSocket = null;

    public TorchAppRunnable(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try {
            // This reads the info
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(),true);
            String str;
            str = in.readLine();
            System.out.println("Client: -> "+str);
            out.println("Thanks !!");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
