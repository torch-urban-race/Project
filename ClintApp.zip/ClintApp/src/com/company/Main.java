package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Main {

    public static void main(String[] args) {
	    String IP = "127.0.0.1";
	    int portNumber =44444;
        Socket clientSocket;

        PrintWriter out;
        BufferedReader in;
        InputStreamReader iR;

        try {
            clientSocket = new Socket(IP,portNumber);
            out = new PrintWriter(clientSocket.getOutputStream(),true);
            iR = new InputStreamReader(clientSocket.getInputStream());
            in = new BufferedReader(iR);
            out.println("InIt");
            System.out.println("Server:-> "+in.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
